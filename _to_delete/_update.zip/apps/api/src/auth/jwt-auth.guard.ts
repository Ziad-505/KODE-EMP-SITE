import {
  ForbiddenException,
  Inject,
  Injectable,
  UnauthorizedException,
  type CanActivate,
  type ExecutionContext,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import type { Permission, Role } from '@kode/contracts';
import type { Request } from 'express';
import { ENV } from '../config/config.module';
import type { Env } from '../config/env';
import { RequestContextStore } from '../common/request-context';
import {
  IS_PUBLIC,
  PERMISSION_MODE,
  REQUIRED_PERMISSIONS,
  REQUIRED_ROLES,
} from './auth.decorators';
import { AuthenticatedUser } from './authenticated-user';
import type { AccessTokenPayload } from './jwt-payload';
import { ACCESS_COOKIE } from './cookie.util';

/**
 * The single authentication and authorization gate. Registered globally in
 * AppModule with APP_GUARD, so every route is protected unless it opts out with
 * @Public(). Authorization is permission-based; see auth.decorators.ts.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly jwt: JwtService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    if (context.getType() !== 'http') return true;

    const targets = [context.getHandler(), context.getClass()];
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC, targets) ?? false;

    const request = context.switchToHttp().getRequest<Request & { user?: AuthenticatedUser }>();
    const token = extractToken(request);

    if (!token) {
      if (isPublic) return true;
      throw new UnauthorizedException('Authentication required');
    }

    let payload: AccessTokenPayload;
    try {
      payload = await this.jwt.verifyAsync<AccessTokenPayload>(token, {
        secret: this.env.JWT_ACCESS_SECRET,
      });
    } catch {
      if (isPublic) return true;
      throw new UnauthorizedException('Session expired');
    }

    if (payload.typ !== 'access') {
      throw new UnauthorizedException('Wrong token type');
    }

    const user = new AuthenticatedUser({
      id: payload.sub,
      email: payload.email,
      role: payload.role,
      departmentId: payload.dept,
      extraPermissions: payload.perm ?? [],
      sessionId: payload.sid,
    });

    request.user = user;
    RequestContextStore.setUserId(user.id);

    if (isPublic) return true;

    const requiredRoles = this.reflector.getAllAndOverride<Role[]>(REQUIRED_ROLES, targets);
    if (requiredRoles?.length && !requiredRoles.includes(user.role)) {
      throw new ForbiddenException('Your role does not allow this action');
    }

    const required = this.reflector.getAllAndOverride<Permission[]>(REQUIRED_PERMISSIONS, targets);
    if (required?.length) {
      const mode =
        this.reflector.getAllAndOverride<'any' | 'all'>(PERMISSION_MODE, targets) ?? 'all';
      const allowed = mode === 'any' ? user.canAny(required) : user.canAll(required);
      if (!allowed) {
        throw new ForbiddenException(
          `Missing permission: ${required.join(mode === 'any' ? ' or ' : ', ')}`,
        );
      }
    }

    return true;
  }
}

function extractToken(request: Request): string | null {
  const header = request.headers.authorization;
  if (header?.startsWith('Bearer ')) {
    return header.slice(7).trim() || null;
  }
  const cookies = (request as Request & { cookies?: Record<string, string> }).cookies;
  return cookies?.[ACCESS_COOKIE] ?? null;
}
