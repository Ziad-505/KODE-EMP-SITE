import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import type { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { MailService } from '../mail/mail.service';

export const OutboxTopic = {
  TICKET_CREATED: 'ticket.created',
  TICKET_UPDATED: 'ticket.updated',
} as const;
export type OutboxTopic = (typeof OutboxTopic)[keyof typeof OutboxTopic];

interface EmailPayload {
  to: string;
  subject: string;
  text: string;
  replyTo?: string;
  ticketId?: string;
}

const MAX_ATTEMPTS = 6;

/**
 * Transactional outbox.
 *
 * A support ticket and its notification are written in the same database
 * transaction, so the system can never be in a state where the ticket exists
 * but the email was lost, or the email went out for a ticket that rolled back.
 * A background worker drains the table with exponential backoff.
 */
@Injectable()
export class OutboxService {
  private readonly logger = new Logger(OutboxService.name);
  private draining = false;

  constructor(
    private readonly prisma: PrismaService,
    private readonly mail: MailService,
  ) {}

  /** Call inside an existing transaction. */
  enqueue(tx: Prisma.TransactionClient, topic: OutboxTopic, payload: EmailPayload) {
    return tx.outboxMessage.create({
      data: { topic, payload: payload as unknown as Prisma.InputJsonValue },
    });
  }

  @Cron(CronExpression.EVERY_30_SECONDS)
  async drain(): Promise<void> {
    if (this.draining) return;
    this.draining = true;
    try {
      const due = await this.prisma.outboxMessage.findMany({
        where: {
          processedAt: null,
          attempts: { lt: MAX_ATTEMPTS },
          nextAttemptAt: { lte: new Date() },
        },
        orderBy: { createdAt: 'asc' },
        take: 20,
      });

      for (const message of due) {
        const payload = message.payload as unknown as EmailPayload;
        try {
          await this.mail.send({
            to: payload.to,
            subject: payload.subject,
            text: payload.text,
            ...(payload.replyTo ? { replyTo: payload.replyTo } : {}),
          });
          await this.prisma.outboxMessage.update({
            where: { id: message.id },
            data: { processedAt: new Date(), lastError: null },
          });
          if (payload.ticketId) {
            await this.prisma.supportTicket
              .update({ where: { id: payload.ticketId }, data: { notifiedAt: new Date() } })
              .catch(() => undefined);
          }
        } catch (error) {
          const attempts = message.attempts + 1;
          // 1m, 2m, 4m, 8m, 16m, 32m
          const backoffMs = Math.min(2 ** attempts, 64) * 30_000;
          await this.prisma.outboxMessage.update({
            where: { id: message.id },
            data: {
              attempts,
              lastError: (error instanceof Error ? error.message : String(error)).slice(0, 500),
              nextAttemptAt: new Date(Date.now() + backoffMs),
            },
          });
          this.logger.warn(
            `Outbox delivery failed (attempt ${attempts}/${MAX_ATTEMPTS}) for ${message.id}`,
          );
        }
      }
    } finally {
      this.draining = false;
    }
  }

  async deadLetterCount(): Promise<number> {
    return this.prisma.outboxMessage.count({
      where: { processedAt: null, attempts: { gte: MAX_ATTEMPTS } },
    });
  }
}
