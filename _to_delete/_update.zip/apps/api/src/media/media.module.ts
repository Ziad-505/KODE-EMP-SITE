import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { MediaController } from './media.controller';
import { MediaService } from './media.service';
import { MediaUrlModule } from './media-url.module';

@Module({
  imports: [AuditModule, MediaUrlModule],
  controllers: [MediaController],
  providers: [MediaService],
  exports: [MediaService, MediaUrlModule],
})
export class MediaModule {}
