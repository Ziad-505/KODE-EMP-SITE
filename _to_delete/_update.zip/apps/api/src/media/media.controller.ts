import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Inject,
  Param,
  Patch,
  Post,
  Query,
  Res,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import {
  Permission,
  listMediaQuerySchema,
  updateMediaSchema,
  type ListMediaQuery,
  type MediaDto,
  type Page,
  type UpdateMediaInput,
} from '@kode/contracts';
import type { Response } from 'express';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { ZodBody, ZodQuery } from '../common/zod-validation.pipe';
import { CurrentUser, Public, RequirePermissions } from '../auth/auth.decorators';
import type { AuthenticatedUser } from '../auth/authenticated-user';
import { ENV } from '../config/config.module';
import type { Env } from '../config/env';
import { MediaService } from './media.service';
import { PrismaService } from '../prisma/prisma.service';

@ApiTags('media')
@Controller('media')
export class MediaController {
  constructor(
    private readonly media: MediaService,
    private readonly prisma: PrismaService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  @Post()
  @RequirePermissions(Permission.MEDIA_UPLOAD)
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 25 * 1024 * 1024, files: 1 } }))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } },
  })
  @ApiOperation({ summary: 'Upload a file to the media library' })
  upload(
    @UploadedFile() file: Express.Multer.File,
    @CurrentUser() actor: AuthenticatedUser,
  ): Promise<MediaDto> {
    return this.media.upload(file, actor);
  }

  @Get()
  @RequirePermissions(Permission.MEDIA_READ)
  @ApiOperation({ summary: 'Browse the media library' })
  list(@Query(ZodQuery(listMediaQuerySchema)) query: ListMediaQuery): Promise<Page<MediaDto>> {
    return this.media.list(query);
  }

  @Get('item/:id')
  @RequirePermissions(Permission.MEDIA_READ)
  findOne(@Param('id') id: string): Promise<MediaDto> {
    return this.media.findOne(id);
  }

  @Patch('item/:id')
  @RequirePermissions(Permission.MEDIA_UPLOAD)
  update(
    @Param('id') id: string,
    @Body(ZodBody(updateMediaSchema)) input: UpdateMediaInput,
    @CurrentUser() actor: AuthenticatedUser,
  ): Promise<MediaDto> {
    return this.media.update(id, input, actor);
  }

  @Delete('item/:id')
  @RequirePermissions(Permission.MEDIA_DELETE)
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: string, @CurrentUser() actor: AuthenticatedUser): Promise<void> {
    return this.media.remove(id, actor);
  }

  /**
   * Serves the bytes. Public because portal images are embedded in pages that
   * are themselves behind auth at the app level, and because signing every
   * image URL would defeat browser caching for no meaningful gain here.
   *
   * The response is forced to a download-safe disposition and a restrictive CSP
   * so an uploaded document can never execute in the API's origin.
   */
  @Public()
  @Get(':shard/:name')
  async serve(
    @Param('shard') shard: string,
    @Param('name') name: string,
    @Res() response: Response,
  ): Promise<void> {
    const storageKey = `${shard}/${name}`;
    const record = await this.prisma.media.findFirst({
      where: { storageKey, deletedAt: null },
      select: { mimeType: true, filename: true, size: true },
    });
    if (!record) {
      response.status(HttpStatus.NOT_FOUND).json({ statusCode: 404, message: 'File not found' });
      return;
    }

    const path = this.media.resolveStoragePath(storageKey);
    const info = await stat(path).catch(() => null);
    if (!info?.isFile()) {
      response.status(HttpStatus.NOT_FOUND).json({ statusCode: 404, message: 'File not found' });
      return;
    }

    const isImage = record.mimeType.startsWith('image/');
    response.setHeader('Content-Type', record.mimeType);
    response.setHeader('Content-Length', info.size);
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
    response.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    response.setHeader(
      'Content-Disposition',
      `${isImage ? 'inline' : 'attachment'}; filename="${encodeURIComponent(record.filename)}"`,
    );
    response.setHeader(
      'Cache-Control',
      this.env.isProduction ? 'public, max-age=31536000, immutable' : 'no-store',
    );

    createReadStream(path).pipe(response);
  }
}
