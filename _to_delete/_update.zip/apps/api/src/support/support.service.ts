import { ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import {
  AuditAction,
  Permission,
  TicketCategory,
  TicketPriority,
  TicketStatus,
  type CreateTicketInput,
  type ListTicketsQuery,
  type Page,
  type TicketDto,
  type UpdateTicketInput,
} from '@kode/contracts';
import { ENV } from '../config/config.module';
import type { Env } from '../config/env';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { OutboxService, OutboxTopic } from '../outbox/outbox.service';
import type { AuthenticatedUser } from '../auth/authenticated-user';

const INCLUDE = {
  requester: {
    select: {
      id: true,
      firstName: true,
      lastName: true,
      email: true,
      department: { select: { name: true } },
    },
  },
  assignee: { select: { id: true, firstName: true, lastName: true } },
} satisfies Prisma.SupportTicketInclude;

type TicketRow = Prisma.SupportTicketGetPayload<{ include: typeof INCLUDE }>;

@Injectable()
export class SupportService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly outbox: OutboxService,
    @Inject(ENV) private readonly env: Env,
  ) {}

  async create(input: CreateTicketInput, actor: AuthenticatedUser): Promise<TicketDto> {
    const requester = await this.prisma.user.findUniqueOrThrow({
      where: { id: actor.id },
      select: {
        firstName: true,
        lastName: true,
        email: true,
        department: { select: { name: true } },
      },
    });

    // Ticket row and outbound notification commit together, so a crash cannot
    // produce a ticket nobody was told about.
    const ticket = await this.prisma.$transaction(async (tx) => {
      const reference = await this.nextReference(tx);
      const created = await tx.supportTicket.create({
        data: {
          reference,
          subject: input.subject,
          body: input.body,
          category: input.category,
          priority: input.priority,
          location: input.location ?? null,
          requesterId: actor.id,
          ...(input.attachmentIds.length
            ? { attachments: { create: input.attachmentIds.map((mediaId) => ({ mediaId })) } }
            : {}),
        },
        include: INCLUDE,
      });

      await this.outbox.enqueue(tx, OutboxTopic.TICKET_CREATED, {
        to: this.env.IT_SUPPORT_INBOX,
        replyTo: requester.email,
        subject: `[${reference}] ${input.subject}`,
        text: buildTicketEmail(created, requester),
        ticketId: created.id,
      });

      return created;
    });

    await this.audit.record({
      action: AuditAction.CREATE,
      entityType: 'SupportTicket',
      entityId: ticket.id,
      summary: `Raised IT request ${ticket.reference}: ${ticket.subject}`,
      actorId: actor.id,
    });

    return this.toDto(ticket);
  }

  async list(query: ListTicketsQuery, actor: AuthenticatedUser): Promise<Page<TicketDto>> {
    // Anyone can read their own tickets; reading everyone's needs a permission.
    const canSeeAll = actor.can(Permission.TICKET_READ_ALL);
    const mode = 'insensitive' as const;

    const where: Prisma.SupportTicketWhereInput = {
      ...(canSeeAll && !query.mine ? {} : { requesterId: actor.id }),
      ...(query.status ? { status: query.status } : {}),
      ...(query.priority ? { priority: query.priority } : {}),
      ...(query.q
        ? {
            OR: [
              { subject: { contains: query.q, mode } },
              { body: { contains: query.q, mode } },
              { reference: { contains: query.q, mode } },
            ],
          }
        : {}),
    };

    const [total, rows] = await this.prisma.$transaction([
      this.prisma.supportTicket.count({ where }),
      this.prisma.supportTicket.findMany({
        where,
        include: INCLUDE,
        orderBy: [{ status: 'asc' }, { createdAt: 'desc' }],
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
    ]);

    return {
      items: rows.map((row) => this.toDto(row)),
      meta: {
        page: query.page,
        pageSize: query.pageSize,
        total,
        totalPages: Math.ceil(total / query.pageSize),
      },
    };
  }

  async findOne(id: string, actor: AuthenticatedUser): Promise<TicketDto> {
    const ticket = await this.prisma.supportTicket.findUnique({ where: { id }, include: INCLUDE });
    if (!ticket) throw new NotFoundException('Request not found');
    if (ticket.requesterId !== actor.id && !actor.can(Permission.TICKET_READ_ALL)) {
      throw new ForbiddenException('That request belongs to someone else');
    }
    return this.toDto(ticket);
  }

  async update(id: string, input: UpdateTicketInput, actor: AuthenticatedUser): Promise<TicketDto> {
    if (!actor.can(Permission.TICKET_MANAGE)) {
      throw new ForbiddenException('You cannot manage support requests');
    }
    const existing = await this.prisma.supportTicket.findUnique({
      where: { id },
      include: INCLUDE,
    });
    if (!existing) throw new NotFoundException('Request not found');

    const ticket = await this.prisma.supportTicket.update({
      where: { id },
      data: {
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(input.priority !== undefined ? { priority: input.priority } : {}),
        ...(input.assigneeId !== undefined ? { assigneeId: input.assigneeId ?? null } : {}),
        ...(input.resolution !== undefined ? { resolution: input.resolution ?? null } : {}),
      },
      include: INCLUDE,
    });

    await this.audit.record({
      action: AuditAction.UPDATE,
      entityType: 'SupportTicket',
      entityId: id,
      summary: `Updated ${ticket.reference} (${existing.status} to ${ticket.status})`,
      actorId: actor.id,
      changes: AuditService.diff(
        { status: existing.status, priority: existing.priority, assigneeId: existing.assigneeId },
        { status: ticket.status, priority: ticket.priority, assigneeId: ticket.assigneeId },
      ),
    });

    return this.toDto(ticket);
  }

  /**
   * KODE-IT-000001 upward. Derived inside the transaction from the current row
   * count so two concurrent submissions cannot collide on the same reference;
   * the unique index is the backstop if they do.
   */
  private async nextReference(tx: Prisma.TransactionClient): Promise<string> {
    const count = await tx.supportTicket.count();
    return `KODE-IT-${String(count + 1).padStart(6, '0')}`;
  }

  toDto(row: TicketRow): TicketDto {
    return {
      id: row.id,
      reference: row.reference,
      subject: row.subject,
      body: row.body,
      category: row.category as TicketCategory,
      priority: row.priority as TicketPriority,
      status: row.status as TicketStatus,
      location: row.location,
      resolution: row.resolution,
      requester: {
        id: row.requester.id,
        displayName: `${row.requester.firstName} ${row.requester.lastName}`.trim(),
        email: row.requester.email,
        departmentName: row.requester.department?.name ?? null,
      },
      assignee: row.assignee
        ? {
            id: row.assignee.id,
            displayName: `${row.assignee.firstName} ${row.assignee.lastName}`.trim(),
          }
        : null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}

/**
 * Plain text on purpose. The IT inbox feeds Odoo, which parses the body; a
 * predictable key/value block survives that better than styled HTML.
 */
function buildTicketEmail(
  ticket: {
    reference: string;
    subject: string;
    body: string;
    category: string;
    priority: string;
    location: string | null;
  },
  requester: {
    firstName: string;
    lastName: string;
    email: string;
    department: { name: string } | null;
  },
): string {
  return [
    `Reference: ${ticket.reference}`,
    `Requester: ${requester.firstName} ${requester.lastName} <${requester.email}>`,
    `Department: ${requester.department?.name ?? 'Not set'}`,
    `Category: ${ticket.category}`,
    `Priority: ${ticket.priority}`,
    `Location: ${ticket.location ?? 'Not given'}`,
    '',
    `Subject: ${ticket.subject}`,
    '',
    ticket.body,
    '',
    '--',
    'Raised from the KODE Sports Club employee portal.',
  ].join('\n');
}
