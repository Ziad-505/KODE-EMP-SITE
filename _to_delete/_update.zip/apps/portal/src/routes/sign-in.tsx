import { useState, type FormEvent } from 'react';
import { Navigate, useLocation, useSearchParams } from 'react-router-dom';
import { loginSchema } from '@kode/contracts';
import { ApiError } from '../lib/api-client';
import { useAuth } from '../lib/auth-context';
import { Icon } from '../components/icon';

export function SignInPage() {
  const { status, signIn, providers } = useAuth();
  const location = useLocation();
  const [params] = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(params.get('error'));
  const [submitting, setSubmitting] = useState(false);

  const from = (location.state as { from?: string } | null)?.from ?? '/';
  if (status === 'authenticated') return <Navigate to={from} replace />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setFormError(null);

    // The same schema the API validates against, so the messages match.
    const parsed = loginSchema.safeParse({ email, password });
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0];
        if (typeof key === 'string' && !next[key]) next[key] = issue.message;
      }
      setErrors(next);
      return;
    }

    setErrors({});
    setSubmitting(true);
    try {
      await signIn(parsed.data);
    } catch (error) {
      setFormError(error instanceof ApiError ? error.message : 'Sign-in failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  const entraUrl = `/api/v1/auth/entra/start?redirectTo=${encodeURIComponent(window.location.origin + from)}`;

  return (
    <div className="auth-screen">
      <aside className="auth-poster">
        <p className="micro-label">KODE SPORTS CLUB / EMPLOYEE PORTAL</p>
        <div>
          <h1>
            THE CLUB,
            <br />
            <em>FROM THE</em>
            <br />
            INSIDE.
          </h1>
          <p>News, events, policies, people and the IT helpdesk. One place, one sign-in.</p>
        </div>
        <div className="auth-rhythm" aria-hidden="true">
          {Array.from({ length: 14 }, (_, index) => (
            <i key={index} />
          ))}
        </div>
      </aside>

      <main className="auth-panel">
        <div className="auth-card">
          <p className="micro-label">WELCOME BACK</p>
          <h2>Sign in.</h2>
          <p>Use your KODE account. If you sign in to Outlook with Microsoft, use that button.</p>

          {formError ? (
            <p className="form-alert" role="alert">
              {formError}
            </p>
          ) : null}

          <form className="auth-form" onSubmit={onSubmit} noValidate>
            <label className="field" data-invalid={Boolean(errors.email)}>
              <span>WORK EMAIL</span>
              <input
                type="email"
                name="email"
                autoComplete="username"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@kodesportsclub.com"
                aria-invalid={Boolean(errors.email)}
                required
              />
              {errors.email ? <span className="field-error">{errors.email}</span> : null}
            </label>

            <label className="field" data-invalid={Boolean(errors.password)}>
              <span>PASSWORD</span>
              <input
                type="password"
                name="password"
                autoComplete="current-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                aria-invalid={Boolean(errors.password)}
                required
              />
              {errors.password ? <span className="field-error">{errors.password}</span> : null}
            </label>

            <button className="ink-button" type="submit" disabled={submitting}>
              {submitting ? 'SIGNING IN...' : 'SIGN IN'} <Icon name="arrow" />
            </button>
          </form>

          {providers.entra ? (
            <>
              <div className="auth-divider">OR</div>
              <a className="entra-button" href={entraUrl}>
                <span className="entra-mark" aria-hidden="true">
                  <i />
                  <i />
                  <i />
                  <i />
                </span>
                CONTINUE WITH MICROSOFT
              </a>
            </>
          ) : null}

          <p className="auth-hint">
            Trouble signing in? Contact KODE IT and they will reset your access. Repeated failed
            attempts lock the account for a short period.
          </p>
        </div>
      </main>
    </div>
  );
}
