# Windows helper. Equivalent to `make setup && make up && make seed`.
# Run from the repository root in PowerShell:  .\setup.ps1
$ErrorActionPreference = 'Stop'

Write-Host "1/5  Installing dependencies..." -ForegroundColor Cyan
corepack enable
pnpm install

Write-Host "2/5  Preparing local config..." -ForegroundColor Cyan
if (-not (Test-Path "apps/api/.env")) {
  Copy-Item "apps/api/.env.example" "apps/api/.env"
  Write-Host "     created apps/api/.env from the example"
}
pnpm --filter '@kode/contracts' build
pnpm --filter '@kode/api' exec prisma generate

Write-Host "3/5  Starting Postgres, Mailpit and the API in Docker..." -ForegroundColor Cyan
docker compose -f docker-compose.dev.yml up -d --build

Write-Host "4/5  Waiting for the API..." -ForegroundColor Cyan
$ready = $false
foreach ($i in 1..40) {
  try {
    Invoke-WebRequest -UseBasicParsing "http://localhost:4000/api/v1/health/ready" -TimeoutSec 3 | Out-Null
    $ready = $true; break
  } catch { Start-Sleep -Seconds 2 }
}
if (-not $ready) {
  Write-Host "     API did not become ready." -ForegroundColor Red
  Write-Host "     Check: docker compose -f docker-compose.dev.yml logs api" -ForegroundColor Red
  exit 1
}
Write-Host "     API ready on http://localhost:4000"

Write-Host "5/5  Seeding demo data..." -ForegroundColor Cyan
pnpm --filter '@kode/api' db:seed

Write-Host ""
Write-Host "Ready. Now run:  pnpm --parallel --filter '@kode/portal' --filter '@kode/admin' dev" -ForegroundColor Green
Write-Host "  Portal  http://localhost:5173"
Write-Host "  CMS     http://localhost:5174"
Write-Host "  Mail    http://localhost:8025"
