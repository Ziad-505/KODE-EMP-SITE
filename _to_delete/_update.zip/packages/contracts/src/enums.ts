export const ContentStatus = {
  DRAFT: 'DRAFT',
  IN_REVIEW: 'IN_REVIEW',
  PUBLISHED: 'PUBLISHED',
  ARCHIVED: 'ARCHIVED',
} as const;
export type ContentStatus = (typeof ContentStatus)[keyof typeof ContentStatus];
export const ALL_CONTENT_STATUSES = Object.values(ContentStatus) as readonly ContentStatus[];

export const CONTENT_STATUS_LABEL: Record<ContentStatus, string> = {
  DRAFT: 'Draft',
  IN_REVIEW: 'In review',
  PUBLISHED: 'Published',
  ARCHIVED: 'Archived',
};

/** Legal status transitions. Anything not listed here is rejected server-side. */
export const CONTENT_STATUS_TRANSITIONS: Record<ContentStatus, readonly ContentStatus[]> = {
  DRAFT: ['IN_REVIEW', 'PUBLISHED', 'ARCHIVED'],
  IN_REVIEW: ['DRAFT', 'PUBLISHED', 'ARCHIVED'],
  PUBLISHED: ['ARCHIVED', 'DRAFT'],
  ARCHIVED: ['DRAFT'],
};

export const UserStatus = {
  ACTIVE: 'ACTIVE',
  INVITED: 'INVITED',
  SUSPENDED: 'SUSPENDED',
} as const;
export type UserStatus = (typeof UserStatus)[keyof typeof UserStatus];

export const TicketStatus = {
  OPEN: 'OPEN',
  ACKNOWLEDGED: 'ACKNOWLEDGED',
  IN_PROGRESS: 'IN_PROGRESS',
  RESOLVED: 'RESOLVED',
  CLOSED: 'CLOSED',
} as const;
export type TicketStatus = (typeof TicketStatus)[keyof typeof TicketStatus];
export const ALL_TICKET_STATUSES = Object.values(TicketStatus) as readonly TicketStatus[];

export const TicketPriority = {
  LOW: 'LOW',
  NORMAL: 'NORMAL',
  HIGH: 'HIGH',
  URGENT: 'URGENT',
} as const;
export type TicketPriority = (typeof TicketPriority)[keyof typeof TicketPriority];
export const ALL_TICKET_PRIORITIES = Object.values(TicketPriority) as readonly TicketPriority[];

export const TicketCategory = {
  HARDWARE: 'HARDWARE',
  SOFTWARE: 'SOFTWARE',
  NETWORK: 'NETWORK',
  ACCESS: 'ACCESS',
  OTHER: 'OTHER',
} as const;
export type TicketCategory = (typeof TicketCategory)[keyof typeof TicketCategory];
export const ALL_TICKET_CATEGORIES = Object.values(TicketCategory) as readonly TicketCategory[];

export const EventKind = {
  CLUB_MOMENT: 'CLUB_MOMENT',
  LEARNING: 'LEARNING',
  WELLBEING: 'WELLBEING',
  ANNOUNCEMENT: 'ANNOUNCEMENT',
} as const;
export type EventKind = (typeof EventKind)[keyof typeof EventKind];
export const ALL_EVENT_KINDS = Object.values(EventKind) as readonly EventKind[];

export const EVENT_KIND_LABEL: Record<EventKind, string> = {
  CLUB_MOMENT: 'Club moment',
  LEARNING: 'Learning',
  WELLBEING: 'Wellbeing',
  ANNOUNCEMENT: 'Announcement',
};

export const AuthProvider = {
  LOCAL: 'LOCAL',
  ENTRA_ID: 'ENTRA_ID',
} as const;
export type AuthProvider = (typeof AuthProvider)[keyof typeof AuthProvider];

export const AuditAction = {
  CREATE: 'CREATE',
  UPDATE: 'UPDATE',
  DELETE: 'DELETE',
  PUBLISH: 'PUBLISH',
  ARCHIVE: 'ARCHIVE',
  LOGIN: 'LOGIN',
  LOGIN_FAILED: 'LOGIN_FAILED',
  LOGOUT: 'LOGOUT',
  ROLE_CHANGE: 'ROLE_CHANGE',
  PASSWORD_CHANGE: 'PASSWORD_CHANGE',
  PERMISSION_DENIED: 'PERMISSION_DENIED',
  UPLOAD: 'UPLOAD',
} as const;
export type AuditAction = (typeof AuditAction)[keyof typeof AuditAction];
